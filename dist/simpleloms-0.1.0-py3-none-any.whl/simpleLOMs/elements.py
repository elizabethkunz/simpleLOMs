"""
elements.py
-----------
Primitive lumped-element circuit blocks built on top of scikit-rf. Each function returns an rf.Network (a 2-port element) that can
be wired into an rf.Circuit connection list.

For netowrks built using these eleemnts see simpleLOMs/networks/.
"""
from __future__ import annotations
import skrf as rf


def coupling_capacitor(C: float, freq: rf.Frequency, name: str = "cc", Z0: float = 50) -> rf.Network:
    """
    Series coupling capacitor.

    Implemented as a SeriesImpedance with Z = 1 / (jωC).

    Parameters
    ----------
    C : float
        Capacitance in Farads.
    freq : rf.Frequency
        Frequency sweep object.
    name : str
        Label used inside rf.Circuit.
    Z0 : float
        Reference impedance in Ohms.

    Returns
    -------
    rf.Network
        2-port series capacitor network.
    """
    return rf.Circuit.SeriesImpedance(
        frequency=freq,
        name=name,
        z0=Z0,
        Z=1 / (1j * freq.w * C),
    )


def shunt_capacitor(C: float, freq: rf.Frequency, name: str = "ctog", Z0: float = 50) -> rf.Network:
    """
    Shunt (to-ground) capacitor.

    Implemented as a ShuntAdmittance with Y = jωC.

    Parameters
    ----------
    C : float
        Capacitance in Farads.
    freq : rf.Frequency
        Frequency sweep object.
    name : str
        Label used inside rf.Circuit.
    Z0 : float
        Reference impedance in Ohms.

    Returns
    -------
    rf.Network
        2-port shunt capacitor network.
    """
    return rf.Circuit.ShuntAdmittance(
        frequency=freq,
        name=name,
        z0=Z0,
        Y=1j * freq.w * C,
    )


def lc_resonator(L: float, C: float, freq: rf.Frequency, name: str = "lc", Z0: float = 50) -> rf.Network:
    """
    Parallel LC resonator shunted to ground.

    Implemented as a ShuntAdmittance with Y = jωC + 1/(jωL), the admittance of a parallel LC tank.

    Parameters
    ----------
    L : float
        Inductance in Henries.
    C : float
        Capacitance in Farads.
    freq : rf.Frequency
        Frequency sweep object.
    name : str
        Label used inside rf.Circuit.
    Z0 : float
        Reference impedance in Ohms.

    Returns
    -------
    rf.Network
        2-port shunt parallel-LC network.
    """
    return rf.Circuit.ShuntAdmittance(
        frequency=freq,
        name=name,
        z0=Z0,
        Y=1j * freq.w * C + 1 / (1j * freq.w * L),
    )
