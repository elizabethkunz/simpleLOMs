"""Simple Lumped Oscillator Models for superconducting quantum device design."""

__version__ = "0.1.0"


"""
simpleLOMs
--------
Lumped-element LC model fitting for CPW microwave resonators.

Quick start
-----------
    import skrf as rf
    from simpleLOMs import analyze_system, CPWParams

    freq = rf.Frequency(4e9, 10e9, 10_001, unit="Hz")
    cpw  = CPWParams(ep_r=11.45)

    results = analyze_system(
        freq=freq,
        d=7e-3,
        Cc1=5e-15, Cc2=5e-15,
        Ctog1=1e-14, Ctog2=1e-14,
        Lload1=5e-10, Cload1=6e-13,
        Lload2=5e-10, Cload2=6e-13,
        cpw_params=cpw,
    )

Or use the model classes directly:

    from simpleLOMs.models.foster_fit import FosterFit
    from simpleLOMs.models.optimized_fit import OptimizedFit
    from simpleLOMs.models.analytical_fit import AnalyticalFit
"""

from simpleLOMs.params import CPWParams
from simpleLOMs.system import analyze_system
from simpleLOMs.models.foster_fit import FosterFit
from simpleLOMs.models.optimized_fit import OptimizedFit, OptimizationConfig
from simpleLOMs.models.analytical_fit import AnalyticalFit
from simpleLOMs.sweeps import (
    SweepConfig,
    sweep,
    sweep_length,
    sweep_coupling,
    sweep_load_frequency,
)

__all__ = [
    "CPWParams",
    "analyze_system",
    "FosterFit",
    "OptimizedFit",
    "OptimizationConfig",
    "AnalyticalFit",
    "SweepConfig",
    "sweep",
    "sweep_length",
    "sweep_coupling",
    "sweep_load_frequency",
]
